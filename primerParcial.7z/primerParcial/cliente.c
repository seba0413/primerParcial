#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "cliente.h"
#include "utn.h"

/** \brief Inicializa un array Cliente
 * \param array Cliente*
 * \param limite int
 * \return int 0 Ok, -1 Error
 *
 */
int cliente_init(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}
/** \brief Imprime los valores cargados
 *
 * \param Cliente array
 * \param int limite
 * \return 0 Ok, -1 Error
 *
 */

int cliente_mostrarDebug(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - %d - %s - %s - %s - %d\n",array[i].idCliente, array[i].nombre, array[i].apellido, array[i].cuit, array[i].isEmpty);
        }
    }
    return retorno;
}
/** \brief Muestra por consola los datos requeridos
 *
 * \param Cliente array
 * \param int limite
 * \return int 0 ok, -1 Error
 *
 */

int cliente_mostrar(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("[RELEASE] - %d - %s - %d\n",array[i].idCliente, array[i].nombre, array[i].isEmpty);
        }
    }
    return retorno;
}

/** \brief Da de alta elementos Cliente harcodeados
 *
 * \param Cliente array
 * \param int limite
 * \param char nombre
 * \return 0 ok, -1 Error
 *
 */

int cliente_altaForzada(Cliente* array,int limite, char* nombre, char* apellido, char* cuit, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibreCliente(array,limite);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(array[i].nombre,nombre);
            strcpy(array[i].apellido, apellido);
            strcpy(array[i].cuit,cuit);
            array[i].idCliente = id;
            array[i].isEmpty = 0;
        }
    }
    return retorno;
}
/** \brief Da el alta de elementos de tipo Cliente
 *
 * \param Cliente array
 * \param int limite
 * \return 0 ok, -1 Error
 *
 */


int cliente_alta(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    char auxiliarNombre[32];
    char auxiliarApellido[32];
    char auxiliarCuit[32];
    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibreCliente(array,limite);
        if(i >= 0)
        {
            if(!getValidString("\nNombre? ","\nEso no es un nombre","El maximo es 32",auxiliarNombre,32,2))
            {
                if(!getValidString("\nApellido? ","\nEso no es un apellido","El maximo es 32",auxiliarApellido,32,2))
                {
                    if(!getStringNumeros("Cuit?", auxiliarCuit))
                     {
                        retorno = 0;
                        strcpy(array[i].nombre,auxiliarNombre);
                        strcpy(array[i].apellido,auxiliarApellido);
                        strcpy(array[i].cuit,auxiliarCuit);
                        array[i].idCliente = proximoIdCliente();
                        array[i].isEmpty = 0;
                     }
                }
            }
        }
        if(!retorno)
        {
            printf("Id cliente: %d", array[i].idCliente);
        }
    }
    return retorno;
}

/** \brief Elimina los elementos requeridos
 *
 * \param Cliente array
 * \param int limite
 * \param int id
 * \return 0 ok, -1 Error
 *
 */

int cliente_baja(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente==id)
            {
                array[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Modifica los datos de un elemento Cliente
 *
 * \param Cliente array
 * \param int limite
 * \param int id
 * \return 0 ok, -1 Error
 *
 */

int cliente_modificacion(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int i;
    char auxiliarNombre[32];
    char auxiliarApellido[32];
    char auxiliarCuit[32];
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente==id)
            {
                if(!getValidString("\nNombre? ","\nEso no es un nombre","El maximo es 40",auxiliarNombre,40,2))
                {
                    if(!getValidString("\nApellido? ","\nEso no es un apellido","El maximo es 32",auxiliarApellido,32,2))
                    {
                        if(!getStringNumeros("Cuit?", auxiliarCuit))
                        {
                            retorno = 0;
                            strcpy(array[i].nombre,auxiliarNombre);
                            strcpy(array[i].apellido,auxiliarApellido);
                            strcpy(array[i].cuit,auxiliarCuit);
                        }
                    }
                }
            }
        }
    }
    return retorno;
}

/** \brief Ordena un array de elementos Cliente
 *
 * \param Cliente array
 * \param int limite
 * \param int orden
 * \return 0 ok, -1 Error
 *
 */


int cliente_ordenar(Cliente* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Cliente auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if((strcmp(array[i].nombre,array[i+1].nombre) > 0 && orden) || (strcmp(array[i].nombre,array[i+1].nombre) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

/** \brief Pide un id y busca el elemento Cliente que coincide con ese id
 *
 * \param Cliente array
 * \param int limite
 * \param int id
 * \return 0 ok, -1 Error
 *
 */

int cliente_buscarPorId(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente==id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Busca un lugar libre en un array Cliente
 *
 * \param Cliente array
 * \param int limite
 * \return 0 ok, -1 Error
 *
 */

int buscarLugarLibreCliente(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Guarda el valor del ultimo id y obtiene el proximo id libre
 *
 * \param void
 * \return int proximoId
 *
 */

int proximoIdCliente()
{
    static int proximoId = 0;
    proximoId++;
    return proximoId;
}
